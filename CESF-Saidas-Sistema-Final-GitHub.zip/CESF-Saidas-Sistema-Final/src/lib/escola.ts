import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Turma = { id: string; nome: string };
export type Aluno = { id: string; nome: string; turma_id: string; turmas: { nome: string } | null };
export type Saida = {
  id: string;
  aluno_id: string;
  destino: string;
  tempo_estimado: number;
  observacao: string | null;
  autorizado_por: string;
  autorizado_por_nome: string;
  saida_em: string;
  retorno_em: string | null;
  alunos: { nome: string; turma_id: string; turmas: { nome: string } | null } | null;
};

export const DESTINOS = [
  "Banheiro",
  "Bebedouro",
  "Coordenação",
  "Secretaria",
  "Enfermaria",
  "Biblioteca",
  "Outro",
];

export function minutosFora(s: Pick<Saida, "saida_em" | "retorno_em">, agora = Date.now()) {
  const fim = s.retorno_em ? new Date(s.retorno_em).getTime() : agora;
  return Math.max(0, Math.floor((fim - new Date(s.saida_em).getTime()) / 60000));
}
export function excedido(s: Saida, agora = Date.now()) {
  return !s.retorno_em && minutosFora(s, agora) > s.tempo_estimado;
}
export const hora = (d: string) =>
  new Date(d).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
export const dataHora = (d: string) => `${new Date(d).toLocaleDateString("pt-BR")} às ${hora(d)}`;

export function useAgora() {
  const [n, setN] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setN(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);
  return n;
}

export const useTurmas = () =>
  useQuery({
    queryKey: ["turmas"],
    queryFn: async () => {
      const { data, error } = await supabase.from("turmas").select("id,nome").order("nome");
      if (error) throw error;
      return data as Turma[];
    },
  });
export const useAlunos = () =>
  useQuery({
    queryKey: ["alunos"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("alunos")
        .select("id,nome,turma_id,turmas(nome)")
        .order("nome");
      if (error) throw error;
      return data as unknown as Aluno[];
    },
  });
const SEL = "*, alunos(nome,turma_id,turmas(nome))";
export const useSaidas = (desde?: string) =>
  useQuery({
    queryKey: ["saidas", desde ?? "all"],
    queryFn: async () => {
      let q = supabase
        .from("saidas")
        .select(SEL)
        .order("saida_em", { ascending: false })
        .limit(500);
      if (desde) q = q.gte("saida_em", desde);
      const { data, error } = await q;
      if (error) throw error;
      return data as unknown as Saida[];
    },
  });
export const useSaida = (id: string) =>
  useQuery({
    queryKey: ["saida", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("saidas").select(SEL).eq("id", id).single();
      if (error) throw error;
      return data as unknown as Saida;
    },
  });
export const useUsuario = () =>
  useQuery({
    queryKey: ["me"],
    queryFn: async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return null;
      const [{ data: p }, { data: r }] = await Promise.all([
        supabase.from("profiles").select("nome,cargo").eq("id", user.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", user.id),
      ]);
      return {
        id: user.id,
        email: user.email ?? "",
        nome: p?.nome || user.email || "",
        cargo: p?.cargo ?? "",
        direcao: (r ?? []).some((x) => x.role === "direcao"),
      };
    },
  });
export function useInvalidarSaidas() {
  const qc = useQueryClient();
  return () => {
    qc.invalidateQueries({ queryKey: ["saidas"] });
    qc.invalidateQueries({ queryKey: ["saida"] });
  };
}
export const inicioDoDia = (d = new Date()) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x.toISOString();
};
