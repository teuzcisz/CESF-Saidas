import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CESF Saídas — Colégio Estadual Sagrada Família" },
      { name: "description", content: "Autorize e acompanhe as saídas de alunos da sala de aula." },
      { property: "og:title", content: "CESF Saídas" },
      {
        property: "og:description",
        content: "Autorize e acompanhe as saídas de alunos da sala de aula.",
      },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ to: "/inicio" });
  },
});
