import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Nova senha — CESF Saídas" },
      { name: "description", content: "Defina uma nova senha de acesso." },
      { property: "og:title", content: "Nova senha — CESF Saídas" },
      { property: "og:description", content: "Defina uma nova senha de acesso." },
    ],
  }),
  component: Reset,
});

function Reset() {
  const nav = useNavigate();
  const [senha, setSenha] = useState("");
  const [conf, setConf] = useState("");
  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    if (senha !== conf) return void toast.error("As senhas não conferem");
    const { error } = await supabase.auth.updateUser({ password: senha });
    if (error) return void toast.error(error.message);
    toast.success("Senha alterada!");
    nav({ to: "/inicio" });
  }
  return (
    <form onSubmit={salvar} className="mx-auto max-w-md space-y-4 px-6 pt-16">
      <h1 className="text-2xl font-bold">Definir nova senha</h1>
      <Input
        required
        type="password"
        minLength={6}
        placeholder="Nova senha"
        value={senha}
        onChange={(e) => setSenha(e.target.value)}
        className="h-12"
      />
      <Input
        required
        type="password"
        minLength={6}
        placeholder="Confirmar senha"
        value={conf}
        onChange={(e) => setConf(e.target.value)}
        className="h-12"
      />
      <Button type="submit" variant="hero" className="h-12 w-full">
        Salvar senha
      </Button>
    </form>
  );
}
