import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { GraduationCap, Users, Search, LogIn, UserPlus, ChevronRight } from "lucide-react";
import { useAlunos, useTurmas, useSaidas } from "@/lib/escola";
import { PageHead, Card } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/inicio")({
  head: () => ({
    meta: [
      { title: "Autorizar Saída — CESF Saídas" },
      { name: "description", content: "Selecione o aluno, defina o destino e autorize a saída." },
      { property: "og:title", content: "Autorizar Saída — CESF Saídas" },
      {
        property: "og:description",
        content: "Selecione o aluno, defina o destino e autorize a saída.",
      },
    ],
  }),
  component: Inicio,
});

function Inicio() {
  const { data: turmas = [] } = useTurmas();
  const { data: alunos = [] } = useAlunos();
  const { data: saidas = [] } = useSaidas();
  const [turma, setTurma] = useState("");
  const [busca, setBusca] = useState("");
  const [todos, setTodos] = useState(false);
  const turmaSel = turma || turmas[0]?.id || "";
  const fora = new Set(saidas.filter((s) => !s.retorno_em).map((s) => s.aluno_id));
  const lista = useMemo(
    () =>
      alunos.filter(
        (a) =>
          (todos || a.turma_id === turmaSel) && a.nome.toLowerCase().includes(busca.toLowerCase()),
      ),
    [alunos, turmaSel, busca, todos],
  );
  return (
    <div>
      <PageHead
        icon={<GraduationCap />}
        title="Autorizar Saída"
        sub="Selecione o aluno, defina o destino e autorize a saída."
      />
      <div className="space-y-3 px-4">
        <label className="flex items-center gap-2 rounded-xl border bg-card px-3 py-2.5 font-semibold shadow-card">
          <Users className="size-5 shrink-0" />
          <select
            className="w-full bg-transparent outline-none"
            value={turmaSel}
            onChange={(e) => {
              setTurma(e.target.value);
              setTodos(false);
            }}
          >
            {turmas.map((t) => (
              <option key={t.id} value={t.id}>
                Turma: {t.nome}
              </option>
            ))}
          </select>
        </label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-11 bg-card pl-10"
            placeholder="Buscar aluno..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>
        {lista.map((a) => (
          <Card key={a.id} className="flex items-center justify-between gap-2 px-3 py-3">
            <div>
              <div className="font-bold">{a.nome}</div>
              <div className="text-xs text-muted-foreground">{a.turmas?.nome}</div>
            </div>
            {fora.has(a.id) ? (
              <span className="text-xs font-semibold text-destructive">Fora de sala</span>
            ) : (
              <Button asChild variant="success" size="sm">
                <Link to="/autorizar/$alunoId" params={{ alunoId: a.id }}>
                  <LogIn />
                  Autorizar
                </Link>
              </Button>
            )}
          </Card>
        ))}
        {lista.length === 0 && (
          <p className="py-6 text-center text-sm text-muted-foreground">Nenhum aluno encontrado.</p>
        )}
        {!todos && (
          <Button variant="outlinePrimary" className="h-11 w-full" onClick={() => setTodos(true)}>
            <UserPlus />
            Ver todos os alunos
            <ChevronRight className="ml-auto" />
          </Button>
        )}
      </div>
    </div>
  );
}
