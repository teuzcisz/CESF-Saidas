import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Check,
  User,
  GraduationCap,
  MapPin,
  Clock,
  CalendarClock,
  Calendar,
  PlusCircle,
  List,
} from "lucide-react";
import { useSaida, dataHora } from "@/lib/escola";
import { Card, Info } from "@/components/app/ui";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/saida/$id")({
  head: () => ({
    meta: [
      { title: "Saída Autorizada — CESF Saídas" },
      { name: "description", content: "A autorização foi registrada com sucesso." },
      { property: "og:title", content: "Saída Autorizada — CESF Saídas" },
      { property: "og:description", content: "A autorização foi registrada com sucesso." },
    ],
  }),
  component: Sucesso,
});

function Sucesso() {
  const { id } = Route.useParams();
  const { data: s } = useSaida(id);
  return (
    <div className="space-y-4 px-4 pt-5">
      <div className="flex items-center gap-3">
        <div className="grid size-16 shrink-0 place-items-center rounded-full bg-success-soft text-success">
          <Check className="size-10" strokeWidth={3} />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Saída Autorizada!</h1>
          <p className="text-sm text-muted-foreground">A autorização foi registrada com sucesso.</p>
        </div>
      </div>
      {s && (
        <Card>
          <Info icon={<User />} label="Aluno" value={s.alunos?.nome} />
          <Info icon={<GraduationCap />} label="Turma" value={s.alunos?.turmas?.nome} />
          <Info icon={<MapPin />} label="Destino" value={s.destino} />
          <Info icon={<Clock />} label="Tempo estimado" value={`${s.tempo_estimado} minutos`} />
          <Info icon={<CalendarClock />} label="Autorizado por" value={s.autorizado_por_nome} />
          <Info icon={<Calendar />} label="Data e horário" value={dataHora(s.saida_em)} />
        </Card>
      )}
      <Button asChild variant="hero" className="h-12 w-full text-base">
        <Link to="/inicio">
          <PlusCircle />
          Nova Autorização
        </Link>
      </Button>
      <Button asChild variant="outlinePrimary" className="h-12 w-full text-base">
        <Link to="/saidas">
          <List />
          Ver Autorizações Ativas
        </Link>
      </Button>
    </div>
  );
}
