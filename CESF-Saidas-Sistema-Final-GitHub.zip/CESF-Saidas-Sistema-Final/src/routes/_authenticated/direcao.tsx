import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Users,
  LogIn,
  CircleCheck,
  AlertTriangle,
  ChevronRight,
  BarChart3,
  Calendar,
  FileText,
  Clock,
  Lock,
} from "lucide-react";
import { useSaidas, useUsuario, inicioDoDia, minutosFora, excedido, useAgora } from "@/lib/escola";
import { PageHead, Card, Pill } from "@/components/app/ui";

export const Route = createFileRoute("/_authenticated/direcao")({
  head: () => ({
    meta: [
      { title: "Painel da Direção — CESF Saídas" },
      {
        name: "description",
        content: "Visão geral das saídas, autorizações e movimentação de alunos.",
      },
      { property: "og:title", content: "Painel da Direção — CESF Saídas" },
      {
        property: "og:description",
        content: "Visão geral das saídas, autorizações e movimentação de alunos.",
      },
    ],
  }),
  component: Direcao,
});

function Direcao() {
  const agora = useAgora();
  const { data: me, isLoading } = useUsuario();
  const { data = [] } = useSaidas(inicioDoDia());
  if (isLoading) return null;
  if (!me?.direcao)
    return (
      <div className="px-6 pt-20 text-center">
        <Lock className="mx-auto size-12 text-muted-foreground" />
        <h1 className="mt-4 text-xl font-bold">Acesso restrito</h1>
        <p className="text-sm text-muted-foreground">Este painel é exclusivo da direção.</p>
      </div>
    );
  const ativas = data.filter((s) => !s.retorno_em);
  const exced = ativas.filter((s) => excedido(s, agora));
  const alunos = new Set(data.map((s) => s.aluno_id)).size;
  const stats = [
    { n: ativas.length, l: "Saídas Ativas", icon: LogIn, c: "bg-success-soft text-success" },
    { n: data.length, l: "Autorizações Hoje", icon: CircleCheck, c: "bg-info-soft text-info" },
    { n: alunos, l: "Alunos Envolvidos", icon: Users, c: "bg-violet-soft text-violet" },
  ];
  return (
    <div>
      <PageHead
        icon={<Users />}
        title="Painel da Direção"
        sub="Visão geral das saídas, autorizações e movimentação de alunos."
      />
      <div className="space-y-4 px-4">
        <div className="grid grid-cols-3 gap-2">
          {stats.map((s) => (
            <div key={s.l} className={`rounded-xl p-3 text-center ${s.c}`}>
              <s.icon className="mx-auto size-6" />
              <div className="text-3xl font-bold text-foreground">{s.n}</div>
              <div className="text-xs text-foreground">{s.l}</div>
            </div>
          ))}
        </div>
        {exced.length > 0 && (
          <Link
            to="/saidas"
            className="flex items-center gap-3 rounded-xl border border-destructive bg-accent p-3"
          >
            <AlertTriangle className="size-7 text-destructive" />
            <div className="flex-1">
              <div className="font-bold text-destructive">
                {exced.length} aluno{exced.length > 1 ? "s" : ""} com tempo excedido
              </div>
              <div className="text-xs">Verificar e tomar as devidas providências.</div>
            </div>
            <ChevronRight />
          </Link>
        )}
        <Card className="p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="flex items-center gap-2 font-bold">
              <LogIn className="size-5" />
              Saídas Ativas
            </span>
            <Link to="/saidas" className="text-xs font-semibold text-primary">
              Ver todas ›
            </Link>
          </div>
          {ativas.slice(0, 5).map((s) => (
            <div
              key={s.id}
              className="flex items-center justify-between border-l-4 border-l-primary py-1.5 pl-2"
            >
              <div>
                <div className="text-sm font-bold">{s.alunos?.nome}</div>
                <div className="text-xs text-muted-foreground">{s.alunos?.turmas?.nome}</div>
              </div>
              <Pill tone={excedido(s, agora) ? "danger" : "success"}>
                <Clock />
                {minutosFora(s, agora)} min
              </Pill>
            </div>
          ))}
          {ativas.length === 0 && (
            <p className="py-3 text-center text-sm text-muted-foreground">Nenhuma saída ativa.</p>
          )}
        </Card>
        <div>
          <div className="mb-2 flex items-center gap-2 font-bold">
            <BarChart3 className="size-5" />
            Relatórios Rápidos
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs font-semibold">
            <Link to="/historico" className="rounded-xl border bg-card p-3 shadow-card">
              <Calendar className="mb-1 size-5 text-primary" />
              Saídas por Período
            </Link>
            <Link to="/historico" className="rounded-xl border bg-card p-3 shadow-card">
              <Users className="mb-1 size-5 text-primary" />
              Por Turma
            </Link>
            <button
              onClick={() => window.print()}
              className="rounded-xl border bg-card p-3 text-left shadow-card"
            >
              <FileText className="mb-1 size-5 text-primary" />
              Exportar Relatório (PDF)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
