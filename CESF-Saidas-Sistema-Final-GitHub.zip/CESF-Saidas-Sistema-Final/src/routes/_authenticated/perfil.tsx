import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { User, KeyRound, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useUsuario } from "@/lib/escola";
import { PageHead, Card } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({
    meta: [
      { title: "Perfil — CESF Saídas" },
      { name: "description", content: "Seus dados de acesso e troca de senha." },
      { property: "og:title", content: "Perfil — CESF Saídas" },
      { property: "og:description", content: "Seus dados de acesso e troca de senha." },
    ],
  }),
  component: Perfil,
});

function Perfil() {
  const nav = useNavigate();
  const { data: me } = useUsuario();
  const [atual, setAtual] = useState("");
  const [nova, setNova] = useState("");
  const [conf, setConf] = useState("");
  async function trocar(e: React.FormEvent) {
    e.preventDefault();
    if (nova !== conf) return void toast.error("As senhas não conferem");
    if (!me) return;
    const { error: e1 } = await supabase.auth.signInWithPassword({
      email: me.email,
      password: atual,
    });
    if (e1) return void toast.error("Senha atual incorreta");
    const { error } = await supabase.auth.updateUser({
      password: nova,
      current_password: atual,
    } as { password: string });
    if (error) return void toast.error(error.message);
    toast.success("Senha alterada com sucesso!");
    setAtual("");
    setNova("");
    setConf("");
  }
  async function sair() {
    await supabase.auth.signOut();
    nav({ to: "/auth" });
  }
  return (
    <div>
      <PageHead
        icon={<User />}
        title={me?.nome || "Perfil"}
        sub={`${me?.cargo ?? ""}${me?.direcao ? " · Direção" : ""} · ${me?.email ?? ""}`}
      />
      <div className="space-y-4 px-4">
        <Card className="p-4">
          <form onSubmit={trocar} className="space-y-3">
            <div className="flex items-center gap-2 font-bold">
              <KeyRound className="size-5" />
              Trocar senha
            </div>
            <Input
              required
              type="password"
              placeholder="Senha atual"
              value={atual}
              onChange={(e) => setAtual(e.target.value)}
              className="h-11"
            />
            <Input
              required
              type="password"
              minLength={6}
              placeholder="Nova senha"
              value={nova}
              onChange={(e) => setNova(e.target.value)}
              className="h-11"
            />
            <Input
              required
              type="password"
              minLength={6}
              placeholder="Confirmar nova senha"
              value={conf}
              onChange={(e) => setConf(e.target.value)}
              className="h-11"
            />
            <Button type="submit" variant="hero" className="h-11 w-full">
              Salvar nova senha
            </Button>
          </form>
        </Card>
        <Button variant="outlinePrimary" className="h-11 w-full" onClick={sair}>
          <LogOut />
          Sair
        </Button>
      </div>
    </div>
  );
}
