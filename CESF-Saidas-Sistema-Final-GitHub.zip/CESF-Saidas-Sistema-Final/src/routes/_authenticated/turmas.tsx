import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, School, X, Check } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useTurmas } from "@/lib/escola";

export const Route = createFileRoute("/_authenticated/turmas")({
  component: TurmasPage,
});

function TurmasPage() {
  const queryClient = useQueryClient();
  const { data: turmas = [], isLoading, error } = useTurmas();

  const [nome, setNome] = useState("");
  const [editandoId, setEditandoId] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);

  const salvarTurma = async () => {
    const nomeLimpo = nome.trim();

    if (!nomeLimpo) {
      toast.error("Digite o nome da turma.");
      return;
    }

    setSalvando(true);

    try {
      if (editandoId) {
        const { error } = await supabase
          .from("turmas")
          .update({ nome: nomeLimpo })
          .eq("id", editandoId);

        if (error) throw error;

        toast.success("Turma atualizada com sucesso!");
      } else {
        const { error } = await supabase.from("turmas").insert({ nome: nomeLimpo });

        if (error) throw error;

        toast.success("Turma cadastrada com sucesso!");
      }

      setNome("");
      setEditandoId(null);
      await queryClient.invalidateQueries({ queryKey: ["turmas"] });
    } catch (err) {
      console.error(err);
      toast.error("Não foi possível salvar a turma.");
    } finally {
      setSalvando(false);
    }
  };

  const iniciarEdicao = (turma: { id: string; nome: string }) => {
    setEditandoId(turma.id);
    setNome(turma.nome);
  };

  const cancelarEdicao = () => {
    setEditandoId(null);
    setNome("");
  };

  const excluirTurma = async (id: string, nomeTurma: string) => {
    const confirmar = window.confirm(`Deseja realmente excluir a turma "${nomeTurma}"?`);

    if (!confirmar) return;

    try {
      const { count, error: consultaErro } = await supabase
        .from("alunos")
        .select("id", { count: "exact", head: true })
        .eq("turma_id", id);

      if (consultaErro) throw consultaErro;

      if ((count ?? 0) > 0) {
        toast.error("Não é possível excluir: existem alunos vinculados a esta turma.");
        return;
      }

      const { error } = await supabase.from("turmas").delete().eq("id", id);

      if (error) throw error;

      toast.success("Turma excluída com sucesso!");
      await queryClient.invalidateQueries({ queryKey: ["turmas"] });
    } catch (err) {
      console.error(err);
      toast.error("Não foi possível excluir a turma.");
    }
  };

  return (
    <div className="space-y-5 p-4">
      <div>
        <div className="mb-2 flex items-center gap-2">
          <School className="size-6 text-primary" />
          <h1 className="text-2xl font-bold">Gerenciar Turmas</h1>
        </div>
        <p className="text-sm text-muted-foreground">Cadastre e organize as turmas do colégio.</p>
      </div>

      <section className="rounded-xl border bg-card p-4 shadow-sm">
        <h2 className="mb-3 font-semibold">
          {editandoId ? "Editar turma" : "Adicionar nova turma"}
        </h2>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void salvarTurma();
          }}
          className="space-y-3"
        >
          <input
            type="text"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            placeholder="Ex.: 1º Ano A"
            maxLength={80}
            className="w-full rounded-lg border bg-background px-3 py-3 text-sm outline-none focus:ring-2 focus:ring-primary"
          />

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={salvando}
              className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-50"
            >
              {editandoId ? <Check className="size-4" /> : <Plus className="size-4" />}
              {salvando ? "Salvando..." : editandoId ? "Salvar alterações" : "Cadastrar turma"}
            </button>

            {editandoId && (
              <button
                type="button"
                onClick={cancelarEdicao}
                className="rounded-lg border px-4 py-3"
                aria-label="Cancelar edição"
              >
                <X className="size-5" />
              </button>
            )}
          </div>
        </form>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Turmas cadastradas</h2>
          <span className="rounded-full bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">
            {turmas.length}
          </span>
        </div>

        {isLoading && (
          <p className="py-6 text-center text-sm text-muted-foreground">Carregando turmas...</p>
        )}

        {error && (
          <p className="rounded-lg border border-destructive/30 p-3 text-sm text-destructive">
            Não foi possível carregar as turmas.
          </p>
        )}

        {!isLoading && !error && turmas.length === 0 && (
          <div className="rounded-xl border border-dashed p-6 text-center">
            <School className="mx-auto mb-2 size-9 text-muted-foreground" />
            <p className="font-medium">Nenhuma turma cadastrada</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Cadastre a primeira turma usando o formulário acima.
            </p>
          </div>
        )}

        {turmas.map((turma) => (
          <div
            key={turma.id}
            className="flex items-center justify-between gap-3 rounded-xl border bg-card p-4"
          >
            <div className="min-w-0">
              <p className="truncate font-semibold">{turma.nome}</p>
              <p className="text-xs text-muted-foreground">Turma do colégio</p>
            </div>

            <div className="flex shrink-0 gap-2">
              <button
                type="button"
                onClick={() => iniciarEdicao(turma)}
                className="rounded-lg border p-2 text-primary"
                aria-label={`Editar ${turma.nome}`}
              >
                <Pencil className="size-4" />
              </button>

              <button
                type="button"
                onClick={() => void excluirTurma(turma.id, turma.nome)}
                className="rounded-lg border p-2 text-destructive"
                aria-label={`Excluir ${turma.nome}`}
              >
                <Trash2 className="size-4" />
              </button>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
