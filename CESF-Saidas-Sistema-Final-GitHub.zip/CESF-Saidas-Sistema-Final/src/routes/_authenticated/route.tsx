import { createFileRoute, Link, Outlet, redirect, useRouterState } from "@tanstack/react-router";
import { Bell, Home, Users, BarChart3, User, Crown, GraduationCap, School } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useUsuario } from "@/lib/escola";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
  },
  component: Layout,
});

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center rounded-md bg-primary-foreground px-1.5 py-1 font-display text-sm font-black text-primary">
        CESF
      </div>
      <div className="border-l border-primary-foreground/40 pl-2 text-sm font-semibold leading-tight">
        Colégio Estadual
        <br />
        Sagrada Família
      </div>
    </div>
  );
}

function Layout() {
  const { data: me } = useUsuario();
  const path = useRouterState({ select: (s) => s.location.pathname });

  const items = [
    {
      to: "/inicio",
      label: "Início",
      icon: Home,
      match: ["/inicio", "/autorizar", "/saida/"],
    },
    {
      to: "/saidas",
      label: "Saídas Ativas",
      icon: Users,
      match: ["/saidas", "/retorno"],
    },
    {
      to: "/historico",
      label: "Relatórios",
      icon: BarChart3,
      match: ["/historico"],
    },
    ...(me?.direcao
      ? [
          {
            to: "/direcao",
            label: "Direção",
            icon: Crown,
            match: ["/direcao"],
          },
          {
            to: "/alunos",
            label: "Alunos",
            icon: GraduationCap,
            match: ["/alunos"],
          },
          {
            to: "/turmas",
            label: "Turmas",
            icon: School,
            match: ["/turmas"],
          },
        ]
      : []),
    {
      to: "/perfil",
      label: "Perfil",
      icon: User,
      match: ["/perfil"],
    },
  ] as const;

  const isActive = (item: (typeof items)[number]) =>
    item.match.some((match) => path.startsWith(match));

  return (
    <div className="min-h-screen bg-background">
      {/* Cabeçalho */}
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between bg-primary px-4 text-primary-foreground shadow-sm md:pl-72 md:px-8">
        <div className="md:hidden">
          <Logo />
        </div>

        <div className="hidden md:block">
          <span className="text-lg font-bold">Sistema CESF</span>
          <p className="text-xs opacity-80">Colégio Estadual Sagrada Família</p>
        </div>

        <div className="flex items-center gap-4">
          <span className="hidden text-sm font-medium sm:block">{me?.nome ?? "Usuário"}</span>
          <Link to="/saidas" aria-label="Avisos">
            <Bell className="size-6" />
          </Link>
        </div>
      </header>

      {/* Menu lateral para computador */}
      <aside className="fixed bottom-0 left-0 top-0 z-40 hidden w-64 flex-col bg-card shadow-md md:flex">
        <div className="flex h-16 items-center border-b px-5">
          <Logo />
        </div>

        <nav className="flex flex-1 flex-col gap-2 overflow-y-auto p-4">
          <p className="mb-2 px-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Menu principal
          </p>

          {items.map((item) => {
            const active = isActive(item);
            const Icon = item.icon;

            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm transition-colors ${
                  active
                    ? "bg-primary font-bold text-primary-foreground"
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <Icon className="size-5 shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t p-4 text-center text-xs text-muted-foreground">
          CESF · Sistema de Saídas
        </div>
      </aside>

      {/* Conteúdo */}
      <main className="mx-auto min-h-[calc(100vh-4rem)] w-full max-w-[1600px] px-3 py-4 pb-24 sm:px-6 md:ml-64 md:w-[calc(100%-16rem)] md:px-8 md:py-8 md:pb-8">
        <Outlet />
      </main>

      {/* Menu inferior para celular */}
      <nav className="fixed bottom-0 left-0 z-40 flex w-full border-t bg-card shadow-lg md:hidden">
        {items.map((item) => {
          const active = isActive(item);
          const Icon = item.icon;

          return (
            <Link
              key={item.to}
              to={item.to}
              className={`flex min-w-0 flex-1 flex-col items-center justify-center gap-1 py-2 text-[10px] transition-colors ${
                active ? "font-bold text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className="size-5" />
              <span className="truncate">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
