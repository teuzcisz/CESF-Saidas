import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  History,
  Calendar,
  Search,
  MapPin,
  LogIn,
  Clock,
  CheckCircle2,
  BarChart3,
} from "lucide-react";
import { useSaidas, useTurmas, hora, inicioDoDia } from "@/lib/escola";
import { PageHead, Card, Pill } from "@/components/app/ui";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/historico")({
  head: () => ({
    meta: [
      { title: "Histórico de Saídas — CESF Saídas" },
      {
        name: "description",
        content: "Consulte os registros de autorizações, saídas e retornos dos alunos.",
      },
      { property: "og:title", content: "Histórico de Saídas — CESF Saídas" },
      {
        property: "og:description",
        content: "Consulte os registros de autorizações, saídas e retornos dos alunos.",
      },
    ],
  }),
  component: Historico,
});

function Historico() {
  const hoje = new Date().toISOString().slice(0, 10);
  const [dia, setDia] = useState(hoje);
  const [turma, setTurma] = useState("");
  const [busca, setBusca] = useState("");
  const { data: turmas = [] } = useTurmas();
  const { data = [] } = useSaidas(inicioDoDia(new Date(dia + "T00:00:00")));
  const fim = new Date(dia + "T00:00:00");
  fim.setDate(fim.getDate() + 1);
  const lista = data.filter(
    (s) =>
      new Date(s.saida_em) < fim &&
      (!turma || s.alunos?.turma_id === turma) &&
      (s.alunos?.nome ?? "").toLowerCase().includes(busca.toLowerCase()),
  );
  const ret = lista.filter((s) => s.retorno_em).length;
  return (
    <div>
      <PageHead
        icon={<History />}
        title="Histórico de Saídas"
        sub="Consulte os registros de autorizações, saídas e retornos dos alunos."
      />
      <div className="space-y-3 px-4">
        <div className="grid grid-cols-2 gap-2">
          <label className="flex items-center gap-2 rounded-md border bg-card px-2">
            <Calendar className="size-4 shrink-0" />
            <input
              type="date"
              value={dia}
              onChange={(e) => setDia(e.target.value || hoje)}
              className="h-10 w-full bg-transparent text-sm font-semibold outline-none"
            />
          </label>
          <select
            value={turma}
            onChange={(e) => setTurma(e.target.value)}
            className="h-10 rounded-md border bg-card px-2 text-sm font-semibold"
          >
            <option value="">Todas as turmas</option>
            {turmas.map((t) => (
              <option key={t.id} value={t.id}>
                {t.nome}
              </option>
            ))}
          </select>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-11 bg-card pl-10"
            placeholder="Buscar aluno..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>
        {lista.map((s) => (
          <Card
            key={s.id}
            className={`border-l-4 p-3 ${s.retorno_em ? "border-l-success" : "border-l-destructive"}`}
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-bold">{s.alunos?.nome}</div>
                <div className="text-xs text-muted-foreground">{s.alunos?.turmas?.nome}</div>
              </div>
              {s.retorno_em ? (
                <Pill tone="success">
                  <CheckCircle2 />
                  Retornado
                </Pill>
              ) : (
                <Pill tone="danger">
                  <Clock />
                  Em saída
                </Pill>
              )}
            </div>
            <div className="mt-2 flex gap-4 text-sm font-semibold">
              <span className="flex items-center gap-1">
                <MapPin className="size-4" />
                {s.destino}
              </span>
              <span className="flex items-center gap-1 text-success">
                <LogIn className="size-4" />
                {hora(s.saida_em)}
              </span>
              {s.retorno_em && (
                <span className="flex items-center gap-1 text-success">
                  <Clock className="size-4" />
                  {hora(s.retorno_em)}
                </span>
              )}
            </div>
          </Card>
        ))}
        {lista.length === 0 && (
          <p className="py-6 text-center text-sm text-muted-foreground">
            Nenhum registro neste dia.
          </p>
        )}
        <Card className="p-4">
          <div className="mb-3 flex items-center gap-2 font-bold">
            <BarChart3 className="size-5" />
            Resumo do dia
          </div>
          <div className="grid grid-cols-3 divide-x text-center">
            <div>
              <div className="text-2xl font-bold">{lista.length}</div>
              <div className="text-xs">Autorizações</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{ret}</div>
              <div className="text-xs">Retornos</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{lista.length - ret}</div>
              <div className="text-xs">Em saída</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
