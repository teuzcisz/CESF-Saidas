import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { User, GraduationCap, MapPin, Clock, Hourglass, CheckCircle2, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  useSaida,
  dataHora,
  minutosFora,
  excedido,
  useAgora,
  useInvalidarSaidas,
} from "@/lib/escola";
import { PageHead, Card, Info, Pill } from "@/components/app/ui";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/retorno/$id")({
  head: () => ({
    meta: [
      { title: "Registrar Retorno — CESF Saídas" },
      { name: "description", content: "Confirme o retorno do aluno para a sala de aula." },
      { property: "og:title", content: "Registrar Retorno — CESF Saídas" },
      { property: "og:description", content: "Confirme o retorno do aluno para a sala de aula." },
    ],
  }),
  component: Retorno,
});

function Retorno() {
  const { id } = Route.useParams();
  const nav = useNavigate();
  const agora = useAgora();
  const inval = useInvalidarSaidas();
  const { data: s } = useSaida(id);
  async function confirmar() {
    const { error } = await supabase
      .from("saidas")
      .update({ retorno_em: new Date().toISOString() })
      .eq("id", id);
    if (error) return void toast.error(error.message);
    inval();
    toast.success("Retorno registrado!");
    nav({ to: "/saidas" });
  }
  return (
    <div>
      <PageHead back="/saidas" title="Registrar Retorno" />
      {s && (
        <div className="space-y-4 px-4">
          <Card>
            <Info icon={<User />} label="Aluno" value={s.alunos?.nome} />
            <Info icon={<GraduationCap />} label="Turma" value={s.alunos?.turmas?.nome} />
          </Card>
          <Card>
            <Info icon={<MapPin />} label="Destino" value={s.destino} />
            <Info icon={<Clock />} label="Saída autorizada" value={dataHora(s.saida_em)} />
            <Info
              icon={<Hourglass />}
              label="Tempo fora"
              value={
                <Pill tone={excedido(s, agora) ? "danger" : "success"}>
                  {minutosFora(s, agora)} min
                </Pill>
              }
            />
          </Card>
          {s.retorno_em ? (
            <p className="text-center font-semibold text-success">Retorno já registrado.</p>
          ) : (
            <>
              <p className="pt-2 text-center text-lg font-semibold">
                Confirmar o retorno do aluno?
              </p>
              <Button variant="success" className="h-14 w-full text-lg" onClick={confirmar}>
                <CheckCircle2 className="!size-6" />
                Confirmar Retorno
              </Button>
            </>
          )}
          <Button
            variant="outlinePrimary"
            className="h-12 w-full text-lg"
            onClick={() => nav({ to: "/saidas" })}
          >
            <XCircle className="!size-6" />
            Cancelar
          </Button>
        </div>
      )}
    </div>
  );
}
