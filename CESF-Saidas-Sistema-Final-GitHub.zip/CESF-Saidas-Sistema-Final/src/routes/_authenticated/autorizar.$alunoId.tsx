import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { User, MapPin, Clock, SquarePen, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { DESTINOS, useAlunos, useUsuario, useInvalidarSaidas } from "@/lib/escola";
import { PageHead, Card } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/autorizar/$alunoId")({
  head: () => ({
    meta: [
      { title: "Autorizar Saída — CESF Saídas" },
      { name: "description", content: "Defina o destino e o tempo estimado da saída do aluno." },
      { property: "og:title", content: "Autorizar Saída — CESF Saídas" },
      {
        property: "og:description",
        content: "Defina o destino e o tempo estimado da saída do aluno.",
      },
    ],
  }),
  component: Autorizar,
});

function Autorizar() {
  const { alunoId } = Route.useParams();
  const nav = useNavigate();
  const inval = useInvalidarSaidas();
  const { data: alunos = [] } = useAlunos();
  const { data: me } = useUsuario();
  const aluno = alunos.find((a) => a.id === alunoId);
  const [destino, setDestino] = useState("Banheiro");
  const [tempo, setTempo] = useState<number | "outro">(5);
  const [outro, setOutro] = useState("20");
  const [obs, setObs] = useState("");
  const [salvando, setSalvando] = useState(false);

  async function autorizar() {
    if (!me) return;
    const minutos = tempo === "outro" ? Number(outro) : tempo;
    if (!minutos || minutos < 1) return void toast.error("Informe o tempo estimado");
    setSalvando(true);
    const { data, error } = await supabase
      .from("saidas")
      .insert({
        aluno_id: alunoId,
        destino,
        tempo_estimado: minutos,
        observacao: obs || null,
        autorizado_por: me.id,
        autorizado_por_nome: me.cargo || me.nome,
      })
      .select("id")
      .single();
    setSalvando(false);
    if (error) return void toast.error(error.message);
    inval();
    nav({ to: "/saida/$id", params: { id: data.id } });
  }
  return (
    <div>
      <PageHead back="/inicio" title="Autorizar Saída" />
      <div className="space-y-5 px-4">
        <Card className="flex items-center gap-3 p-4">
          <User className="size-8" />
          <div>
            <div className="text-xs">Aluno</div>
            <div className="text-lg font-bold">{aluno?.nome ?? "..."}</div>
            <div className="text-sm text-muted-foreground">{aluno?.turmas?.nome}</div>
          </div>
        </Card>
        <div className="flex gap-3">
          <MapPin className="mt-7 size-6 shrink-0" />
          <div className="w-full">
            <div className="mb-1 text-sm">Destino</div>
            <select
              value={destino}
              onChange={(e) => setDestino(e.target.value)}
              className="h-11 w-full rounded-md border bg-card px-3 font-semibold"
            >
              {DESTINOS.map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex gap-3">
          <Clock className="mt-1 size-6 shrink-0" />
          <div className="w-full">
            <div className="mb-2 text-sm">Tempo estimado</div>
            <div className="grid grid-cols-4 gap-2">
              {([5, 10, 15, "outro"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTempo(t)}
                  className={`h-10 rounded-md border text-sm font-semibold ${tempo === t ? "bg-primary text-primary-foreground border-primary" : "bg-card"}`}
                >
                  {t === "outro" ? "Outro" : `${t} min`}
                </button>
              ))}
            </div>
            {tempo === "outro" && (
              <Input
                type="number"
                min={1}
                className="mt-2 h-10 bg-card"
                value={outro}
                onChange={(e) => setOutro(e.target.value)}
                placeholder="Minutos"
              />
            )}
          </div>
        </div>
        <div className="flex gap-3">
          <SquarePen className="mt-1 size-6 shrink-0" />
          <div className="w-full">
            <div className="mb-2 text-sm">Observação (opcional)</div>
            <textarea
              value={obs}
              onChange={(e) => setObs(e.target.value)}
              rows={3}
              placeholder="Ex.: Necessidade médica, etc."
              className="w-full rounded-md border bg-card p-3 text-sm"
            />
          </div>
        </div>
        <Button
          variant="success"
          className="h-14 w-full text-lg"
          disabled={salvando || !aluno}
          onClick={autorizar}
        >
          <CheckCircle2 className="!size-6" />
          Autorizar Saída
        </Button>
      </div>
    </div>
  );
}
