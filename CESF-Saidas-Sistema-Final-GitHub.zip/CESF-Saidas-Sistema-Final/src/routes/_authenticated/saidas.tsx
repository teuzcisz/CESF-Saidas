import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { UserRound, LogIn, History, Search, MapPin, Clock, CheckCircle2 } from "lucide-react";
import { useSaidas, hora, excedido, useAgora } from "@/lib/escola";
import { PageHead, Card, Pill } from "@/components/app/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/saidas")({
  head: () => ({
    meta: [
      { title: "Painel do Funcionário — CESF Saídas" },
      {
        name: "description",
        content: "Consulte as saídas autorizadas e registre o retorno do aluno.",
      },
      { property: "og:title", content: "Painel do Funcionário — CESF Saídas" },
      {
        property: "og:description",
        content: "Consulte as saídas autorizadas e registre o retorno do aluno.",
      },
    ],
  }),
  component: Painel,
});

function Painel() {
  const agora = useAgora();
  const { data = [] } = useSaidas();
  const [busca, setBusca] = useState("");
  const ativas = data.filter(
    (s) =>
      !s.retorno_em &&
      `${s.alunos?.nome} ${s.alunos?.turmas?.nome}`.toLowerCase().includes(busca.toLowerCase()),
  );
  return (
    <div>
      <PageHead
        icon={<UserRound />}
        title="Painel do Funcionário"
        sub="Consulte as saídas autorizadas e registre o retorno do aluno."
      />
      <div className="space-y-3 px-4">
        <div className="grid grid-cols-2 gap-1 rounded-xl border bg-card p-1">
          <div className="flex items-center justify-center gap-2 rounded-lg bg-primary py-2 font-semibold text-primary-foreground">
            <LogIn className="size-5" />
            Saídas Ativas ({ativas.length})
          </div>
          <Link
            to="/historico"
            className="flex items-center justify-center gap-2 py-2 font-semibold"
          >
            <History className="size-5" />
            Histórico
          </Link>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-11 bg-card pl-10"
            placeholder="Buscar aluno, turma..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>
        {ativas.map((s) => (
          <Card key={s.id} className="space-y-2 p-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-lg font-bold">{s.alunos?.nome}</div>
                <div className="text-xs text-muted-foreground">{s.alunos?.turmas?.nome}</div>
              </div>
              {excedido(s, agora) ? (
                <Pill tone="danger">● Tempo excedido</Pill>
              ) : (
                <Pill tone="success">● Em saída</Pill>
              )}
            </div>
            <div className="flex items-center justify-between text-sm font-semibold">
              <span className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <MapPin className="size-4" />
                  {s.destino}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="size-4" />
                  {hora(s.saida_em)}
                </span>
              </span>
              <Button asChild variant="success" size="sm">
                <Link to="/retorno/$id" params={{ id: s.id }}>
                  <CheckCircle2 />
                  Registrar Retorno
                </Link>
              </Button>
            </div>
          </Card>
        ))}
        {ativas.length === 0 && (
          <p className="py-8 text-center text-sm text-muted-foreground">
            Nenhum aluno fora de sala agora.
          </p>
        )}
      </div>
    </div>
  );
}
