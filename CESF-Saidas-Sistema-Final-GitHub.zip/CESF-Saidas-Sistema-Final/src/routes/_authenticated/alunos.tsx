import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Plus, Pencil, Trash2, Users, X, GraduationCap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useUsuario } from "@/lib/escola";
import { PageHead, Card } from "@/components/app/ui";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/alunos")({
  component: AlunosPage,
});

type Aluno = {
  id: string;
  nome: string;
  turma_id: string;
  turmas: { nome: string } | null;
};

type Turma = {
  id: string;
  nome: string;
};

function AlunosPage() {
  const queryClient = useQueryClient();
  const { data: me, isLoading: carregandoUsuario } = useUsuario();

  const [busca, setBusca] = useState("");
  const [filtroTurma, setFiltroTurma] = useState("todas");
  const [nome, setNome] = useState("");
  const [turmaId, setTurmaId] = useState("");
  const [editando, setEditando] = useState<string | null>(null);
  const [formAberto, setFormAberto] = useState(false);

  const {
    data: alunos = [],
    isLoading: carregandoAlunos,
    error: erroAlunos,
  } = useQuery({
    queryKey: ["alunos"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("alunos")
        .select("id,nome,turma_id,turmas(nome)")
        .order("nome");

      if (error) throw error;

      return data as unknown as Aluno[];
    },
    enabled: !!me?.direcao,
  });

  const { data: turmas = [], isLoading: carregandoTurmas } = useQuery({
    queryKey: ["turmas"],
    queryFn: async () => {
      const { data, error } = await supabase.from("turmas").select("id,nome").order("nome");

      if (error) throw error;

      return data as Turma[];
    },
    enabled: !!me?.direcao,
  });

  function fecharFormulario() {
    setFormAberto(false);
    setEditando(null);
    setNome("");
    setTurmaId("");
  }

  function abrirCadastro() {
    setNome("");
    setTurmaId("");
    setEditando(null);
    setFormAberto(true);
  }

  function abrirEdicao(aluno: Aluno) {
    setNome(aluno.nome);
    setTurmaId(aluno.turma_id);
    setEditando(aluno.id);
    setFormAberto(true);
  }

  const salvar = useMutation({
    mutationFn: async () => {
      const nomeLimpo = nome.trim();

      if (!nomeLimpo) {
        throw new Error("Informe o nome do aluno.");
      }

      if (!turmaId) {
        throw new Error("Selecione uma turma.");
      }

      if (editando) {
        const { error } = await supabase
          .from("alunos")
          .update({
            nome: nomeLimpo,
            turma_id: turmaId,
          })
          .eq("id", editando);

        if (error) throw error;
      } else {
        const { error } = await supabase.from("alunos").insert({
          nome: nomeLimpo,
          turma_id: turmaId,
        });

        if (error) throw error;
      }
    },

    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["alunos"],
      });

      toast.success(editando ? "Aluno atualizado com sucesso!" : "Aluno cadastrado com sucesso!");

      fecharFormulario();
    },

    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const excluir = useMutation({
    mutationFn: async (aluno: Aluno) => {
      // Verifica se o aluno possui histórico de saídas.
      const { count, error: erroConsulta } = await supabase
        .from("saidas")
        .select("id", {
          count: "exact",
          head: true,
        })
        .eq("aluno_id", aluno.id);

      if (erroConsulta) throw erroConsulta;

      if ((count ?? 0) > 0) {
        throw new Error(
          "Este aluno possui histórico de saídas e não pode ser excluído. O histórico será preservado.",
        );
      }

      const { error } = await supabase.from("alunos").delete().eq("id", aluno.id);

      if (error) throw error;
    },

    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["alunos"],
      });

      toast.success("Aluno excluído com sucesso!");
    },

    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const filtrados = alunos.filter((aluno) => {
    const nomeCorresponde = aluno.nome.toLowerCase().includes(busca.trim().toLowerCase());

    const turmaCorresponde = filtroTurma === "todas" || aluno.turma_id === filtroTurma;

    return nomeCorresponde && turmaCorresponde;
  });

  if (carregandoUsuario) {
    return (
      <div className="p-8 text-center text-sm text-muted-foreground">Verificando acesso...</div>
    );
  }

  if (!me?.direcao) {
    return (
      <div className="px-6 pt-20 text-center">
        <Users className="mx-auto size-12 text-muted-foreground" />
        <h1 className="mt-4 text-xl font-bold">Acesso restrito</h1>
        <p className="text-sm text-muted-foreground">Esta página é exclusiva da direção.</p>
      </div>
    );
  }

  return (
    <div>
      <PageHead
        icon={<GraduationCap />}
        title="Gerenciar Alunos"
        sub="Cadastre, pesquise e organize os alunos da escola."
      />

      <div className="space-y-4 px-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Total de alunos cadastrados</p>
            <p className="text-3xl font-bold">{alunos.length}</p>
          </div>

          <button
            type="button"
            onClick={abrirCadastro}
            className="flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
          >
            <Plus size={18} />
            Novo aluno
          </button>
        </div>

        {formAberto && (
          <Card className="space-y-3 p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold">{editando ? "Editar aluno" : "Cadastrar aluno"}</h2>

              <button type="button" onClick={fecharFormulario} aria-label="Fechar formulário">
                <X />
              </button>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">Nome completo</label>

              <input
                type="text"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Digite o nome do aluno"
                className="w-full rounded-lg border bg-background px-3 py-3 text-sm"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">Turma</label>

              <select
                value={turmaId}
                onChange={(e) => setTurmaId(e.target.value)}
                disabled={carregandoTurmas || turmas.length === 0}
                className="w-full rounded-lg border bg-background px-3 py-3 text-sm"
              >
                <option value="">Selecione uma turma</option>

                {turmas.map((turma) => (
                  <option key={turma.id} value={turma.id}>
                    {turma.nome}
                  </option>
                ))}
              </select>

              {turmas.length === 0 && !carregandoTurmas && (
                <p className="mt-1 text-xs text-destructive">
                  Nenhuma turma cadastrada. Cadastre uma turma antes de adicionar alunos.
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={() => salvar.mutate()}
              disabled={salvar.isPending || carregandoTurmas || turmas.length === 0}
              className="w-full rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground disabled:opacity-50"
            >
              {salvar.isPending
                ? "Salvando..."
                : editando
                  ? "Salvar alterações"
                  : "Cadastrar aluno"}
            </button>
          </Card>
        )}

        <div className="relative">
          <Search className="absolute left-3 top-3 size-5 text-muted-foreground" />

          <input
            type="text"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Pesquisar aluno pelo nome..."
            className="w-full rounded-xl border bg-card py-3 pl-10 pr-3 text-sm"
          />
        </div>

        <select
          value={filtroTurma}
          onChange={(e) => setFiltroTurma(e.target.value)}
          className="w-full rounded-xl border bg-card px-3 py-3 text-sm"
        >
          <option value="todas">Todas as turmas</option>

          {turmas.map((turma) => (
            <option key={turma.id} value={turma.id}>
              {turma.nome}
            </option>
          ))}
        </select>

        <div className="flex items-center gap-2 font-semibold">
          <Users size={19} />
          Alunos encontrados: {filtrados.length}
        </div>

        {erroAlunos && (
          <Card className="border-destructive p-4">
            <p className="text-sm text-destructive">
              Erro ao carregar alunos: {erroAlunos.message}
            </p>
          </Card>
        )}

        {carregandoAlunos ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Carregando alunos...</p>
        ) : (
          <div className="space-y-2">
            {filtrados.map((aluno) => (
              <Card key={aluno.id} className="flex items-center gap-3 p-3">
                <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <GraduationCap size={20} />
                </div>

                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">{aluno.nome}</p>

                  <p className="text-xs text-muted-foreground">
                    {aluno.turmas?.nome ?? "Turma não identificada"}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => abrirEdicao(aluno)}
                  className="rounded-lg p-2 text-primary"
                  aria-label="Editar aluno"
                >
                  <Pencil size={18} />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const confirmar = window.confirm(`Deseja excluir o aluno ${aluno.nome}?`);

                    if (confirmar) {
                      excluir.mutate(aluno);
                    }
                  }}
                  disabled={excluir.isPending}
                  className="rounded-lg p-2 text-destructive disabled:opacity-50"
                  aria-label="Excluir aluno"
                >
                  <Trash2 size={18} />
                </button>
              </Card>
            ))}

            {filtrados.length === 0 && (
              <div className="rounded-xl border border-dashed p-8 text-center">
                <Users className="mx-auto mb-2 text-muted-foreground" />

                <p className="text-sm text-muted-foreground">Nenhum aluno encontrado.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
