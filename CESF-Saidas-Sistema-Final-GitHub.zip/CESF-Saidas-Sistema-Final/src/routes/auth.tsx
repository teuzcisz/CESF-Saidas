import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — CESF Saídas" },
      {
        name: "description",
        content: "Acesse o sistema de saídas do Colégio Sagrada Família.",
      },
      { property: "og:title", content: "Entrar — CESF Saídas" },
      {
        property: "og:description",
        content: "Acesse o sistema de saídas do Colégio Sagrada Família.",
      },
    ],
  }),
  component: AuthPage,
});

type Modo = "entrar" | "cadastrar" | "esqueci";

function AuthPage() {
  const nav = useNavigate();

  const [modo, setModo] = useState<Modo>("entrar");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [nome, setNome] = useState("");
  const [cargo, setCargo] = useState("Professor");
  const [chave, setChave] = useState("");
  const [loading, setLoading] = useState(false);

  async function enviar(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);

    try {
      if (modo === "entrar") {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password: senha,
        });

        if (error) throw error;

        toast.success("Login realizado com sucesso!");
        nav({ to: "/inicio" });
        return;
      }

      if (modo === "cadastrar") {
        if (!nome.trim()) {
          throw new Error("Informe seu nome completo.");
        }

        if (cargo === "Coordenação" && !chave.trim()) {
          throw new Error("Informe a chave de autorização.");
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password: senha,
          options: {
            data: {
              nome: nome.trim(),
              cargo,
            },
          },
        });

        if (error) throw error;

        if (!data.user) {
          throw new Error("Não foi possível criar a conta.");
        }

        if (cargo === "Coordenação") {
          if (!data.session) {
            throw new Error(
              "A conta foi criada, mas não há sessão autenticada. Confira se a confirmação de e-mail está desativada no Supabase.",
            );
          }

          const { error: roleError } = await supabase.rpc("registrar_coordenacao", {
            p_chave: chave,
            p_nome: nome.trim(),
          });

          if (roleError) {
            throw new Error(
              "A conta foi criada, mas a permissão de Coordenação não foi atribuída: " +
                roleError.message,
            );
          }

          toast.success("Conta de Coordenação criada com permissão administrativa!");
        } else {
          toast.success("Cadastro realizado com sucesso!");
        }

        setNome("");
        setEmail("");
        setSenha("");
        setChave("");
        setCargo("Professor");
        setModo("entrar");
        return;
      }

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;

      toast.success("Enviamos um link para redefinir sua senha.");
      setModo("entrar");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Ocorreu um erro.");
    } finally {
      setLoading(false);
    }
  }

  const titulo =
    modo === "entrar" ? "Entrar" : modo === "cadastrar" ? "Criar conta" : "Recuperar senha";

  return (
    <div className="flex min-h-screen flex-col bg-primary">
      <div className="px-6 pb-10 pt-14 text-primary-foreground">
        <div className="inline-block rounded-md bg-primary-foreground px-2 py-1 font-display text-xl font-black text-primary">
          CESF
        </div>

        <h1 className="mt-4 text-3xl font-bold">
          Colégio Estadual
          <br />
          Sagrada Família
        </h1>

        <p className="mt-2 opacity-80">Controle de saídas de alunos</p>
      </div>

      <form
        onSubmit={enviar}
        className="mx-auto w-full max-w-md flex-1 space-y-4 rounded-t-3xl bg-background px-6 pb-10 pt-8"
      >
        <h2 className="text-2xl font-bold">{titulo}</h2>

        {modo === "cadastrar" && (
          <>
            <Input
              required
              placeholder="Nome completo"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="h-12"
            />

            <select
              value={cargo}
              onChange={(e) => {
                setCargo(e.target.value);
                setChave("");
              }}
              className="h-12 w-full rounded-md border bg-card px-3"
            >
              <option value="Professor">Professor</option>
              <option value="Funcionário">Funcionário</option>
              <option value="Coordenação">Coordenação</option>
            </select>

            {cargo === "Coordenação" && (
              <div className="space-y-2">
                <Input
                  required
                  type="password"
                  placeholder="Chave exclusiva da Coordenação"
                  value={chave}
                  onChange={(e) => setChave(e.target.value)}
                  className="h-12"
                />

                <p className="text-xs text-muted-foreground">
                  Informe a chave de autorização para criar uma conta administrativa.
                </p>
              </div>
            )}
          </>
        )}

        <Input
          required
          type="email"
          placeholder="E-mail"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="h-12"
        />

        {modo !== "esqueci" && (
          <Input
            required
            type="password"
            minLength={6}
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className="h-12"
          />
        )}

        <Button
          type="submit"
          variant="hero"
          size="lg"
          className="h-12 w-full text-base"
          disabled={loading}
        >
          {loading
            ? "Aguarde..."
            : modo === "entrar"
              ? "Entrar"
              : modo === "cadastrar"
                ? "Cadastrar"
                : "Enviar link"}
        </Button>

        <div className="flex flex-col items-center gap-2 pt-2 text-sm">
          {modo === "entrar" && (
            <button
              type="button"
              className="font-semibold text-primary"
              onClick={() => setModo("esqueci")}
            >
              Esqueci minha senha
            </button>
          )}

          {modo === "entrar" ? (
            <button type="button" onClick={() => setModo("cadastrar")}>
              Não tem conta? <b className="text-primary">Cadastre-se</b>
            </button>
          ) : (
            <button type="button" onClick={() => setModo("entrar")}>
              Já tem conta? <b className="text-primary">Entrar</b>
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
