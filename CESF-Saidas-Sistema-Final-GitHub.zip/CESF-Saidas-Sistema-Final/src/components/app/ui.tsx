import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";

export function PageHead({
  icon,
  title,
  sub,
  back,
}: {
  icon?: ReactNode;
  title: string;
  sub?: string;
  back?: string;
}) {
  return (
    <div className="flex items-start gap-3 px-4 pt-5 pb-3">
      {back ? (
        <Link to={back} className="mt-1 text-foreground" aria-label="Voltar">
          <ChevronLeft className="size-7" />
        </Link>
      ) : icon ? (
        <div className="grid size-14 shrink-0 place-items-center rounded-full bg-secondary text-foreground [&_svg]:size-7">
          {icon}
        </div>
      ) : null}
      <div>
        <h1 className="text-2xl font-bold leading-tight">{title}</h1>
        {sub && <p className="text-sm text-muted-foreground">{sub}</p>}
      </div>
    </div>
  );
}
export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-xl border bg-card shadow-card ${className}`}>{children}</div>;
}
export function Info({ icon, label, value }: { icon: ReactNode; label: string; value: ReactNode }) {
  return (
    <div className="flex items-center gap-3 border-b px-4 py-3 last:border-0 [&>svg]:size-6 [&>svg]:shrink-0">
      {icon}
      <div>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="font-semibold">{value}</div>
      </div>
    </div>
  );
}
export function Pill({
  tone,
  children,
}: {
  tone: "success" | "danger" | "muted";
  children: ReactNode;
}) {
  const c =
    tone === "success"
      ? "bg-success-soft text-success"
      : tone === "danger"
        ? "bg-accent text-destructive"
        : "bg-muted text-muted-foreground";
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold [&_svg]:size-3 ${c}`}
    >
      {children}
    </span>
  );
}
