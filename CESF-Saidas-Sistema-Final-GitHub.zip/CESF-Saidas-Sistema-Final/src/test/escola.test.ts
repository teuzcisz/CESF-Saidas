import { describe, expect, it } from "vitest";
import { excedido, minutosFora, type Saida } from "@/lib/escola";

const base = {
  saida_em: "2026-11-12T10:00:00Z",
  retorno_em: null,
  tempo_estimado: 5,
} as unknown as Saida;
const t = (min: number) => new Date("2026-11-12T10:00:00Z").getTime() + min * 60000;

describe("tempo fora", () => {
  it("conta minutos desde a saída", () => expect(minutosFora(base, t(3))).toBe(3));
  it("não excede dentro do tempo estimado", () => expect(excedido(base, t(5))).toBe(false));
  it("excede após o tempo estimado", () => expect(excedido(base, t(6))).toBe(true));
  it("aluno que retornou não fica excedido", () =>
    expect(excedido({ ...base, retorno_em: "2026-11-12T10:20:00Z" }, t(30))).toBe(false));
});
