# CESF Saídas - Sistema Final

Código-fonte do sistema CESF Saídas.

## Como executar localmente

1. Instale Node.js.
2. Abra esta pasta no terminal.
3. Execute `npm install`.
4. Copie `.env.example` para `.env.local` e preencha as variáveis com as credenciais do seu próprio projeto Supabase.
5. Execute `npm run dev`.

## Segurança

Arquivos `.env.local`, chaves privadas e credenciais reais não fazem parte deste pacote. Não publique segredos no GitHub. Se o repositório contiver dados reais de estudantes, mantenha-o privado e remova esses dados antes de torná-lo público.
