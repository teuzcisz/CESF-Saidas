CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id)
$$;
REVOKE EXECUTE ON FUNCTION public.is_staff(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.is_staff(uuid) TO authenticated;

DROP POLICY IF EXISTS "alunos all" ON public.alunos;
CREATE POLICY "alunos ver" ON public.alunos FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "alunos direcao insere" ON public.alunos FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'direcao'));
CREATE POLICY "alunos direcao edita" ON public.alunos FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'direcao')) WITH CHECK (public.has_role(auth.uid(), 'direcao'));
CREATE POLICY "alunos direcao apaga" ON public.alunos FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'direcao'));

DROP POLICY IF EXISTS "turmas all" ON public.turmas;
CREATE POLICY "turmas ver" ON public.turmas FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "turmas direcao insere" ON public.turmas FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'direcao'));
CREATE POLICY "turmas direcao edita" ON public.turmas FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'direcao')) WITH CHECK (public.has_role(auth.uid(), 'direcao'));
CREATE POLICY "turmas direcao apaga" ON public.turmas FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'direcao'));

DROP POLICY IF EXISTS "perfis visiveis" ON public.profiles;
CREATE POLICY "ver proprio perfil ou direcao" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id OR public.has_role(auth.uid(), 'direcao'));

DROP POLICY IF EXISTS "saidas update" ON public.saidas;
CREATE POLICY "saidas registrar retorno" ON public.saidas FOR UPDATE TO authenticated
  USING (retorno_em IS NULL AND public.is_staff(auth.uid()))
  WITH CHECK (retorno_em IS NOT NULL);

CREATE OR REPLACE FUNCTION public.saidas_so_retorno() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.aluno_id <> OLD.aluno_id OR NEW.destino <> OLD.destino OR NEW.tempo_estimado <> OLD.tempo_estimado
     OR NEW.observacao IS DISTINCT FROM OLD.observacao OR NEW.autorizado_por <> OLD.autorizado_por
     OR NEW.autorizado_por_nome <> OLD.autorizado_por_nome OR NEW.saida_em <> OLD.saida_em THEN
    RAISE EXCEPTION 'Só é permitido registrar o retorno';
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER saidas_so_retorno BEFORE UPDATE ON public.saidas FOR EACH ROW EXECUTE FUNCTION public.saidas_so_retorno();