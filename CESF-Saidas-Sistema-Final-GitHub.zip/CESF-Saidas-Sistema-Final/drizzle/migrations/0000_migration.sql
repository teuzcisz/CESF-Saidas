CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nome text NOT NULL DEFAULT '',
  cargo text NOT NULL DEFAULT 'Professor',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "perfis visiveis" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "editar proprio" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "inserir proprio" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, nome, cargo) VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'nome', ''), COALESCE(NEW.raw_user_meta_data->>'cargo', 'Professor'));
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.turmas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.turmas TO authenticated;
GRANT ALL ON public.turmas TO service_role;
ALTER TABLE public.turmas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "turmas all" ON public.turmas FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.alunos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  turma_id uuid NOT NULL REFERENCES public.turmas(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.alunos TO authenticated;
GRANT ALL ON public.alunos TO service_role;
ALTER TABLE public.alunos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "alunos all" ON public.alunos FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.saidas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  aluno_id uuid NOT NULL REFERENCES public.alunos(id) ON DELETE CASCADE,
  destino text NOT NULL,
  tempo_estimado int NOT NULL DEFAULT 5,
  observacao text,
  autorizado_por uuid NOT NULL,
  autorizado_por_nome text NOT NULL DEFAULT '',
  saida_em timestamptz NOT NULL DEFAULT now(),
  retorno_em timestamptz
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saidas TO authenticated;
GRANT ALL ON public.saidas TO service_role;
ALTER TABLE public.saidas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "saidas select" ON public.saidas FOR SELECT TO authenticated USING (true);
CREATE POLICY "saidas insert" ON public.saidas FOR INSERT TO authenticated WITH CHECK (auth.uid() = autorizado_por);
CREATE POLICY "saidas update" ON public.saidas FOR UPDATE TO authenticated USING (true);

INSERT INTO public.turmas (id, nome) VALUES
 ('11111111-1111-1111-1111-111111111111', '3º Desenvolvimento de Sistemas'),
 ('22222222-2222-2222-2222-222222222222', '2º Desenvolvimento de Sistemas');
INSERT INTO public.alunos (nome, turma_id) VALUES
 ('Matheus H. Cisz Machado', '11111111-1111-1111-1111-111111111111'),
 ('Cezar Kupka Souza', '11111111-1111-1111-1111-111111111111'),
 ('Heidryck Ribeiro dos Santos', '11111111-1111-1111-1111-111111111111'),
 ('Ana Clara Oliveira', '22222222-2222-2222-2222-222222222222'),
 ('Lucas Pereira Lima', '22222222-2222-2222-2222-222222222222');